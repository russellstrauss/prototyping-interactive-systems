Requirements

Python 3.7: https://www.python.org/downloads/

install pip for package management and run ```pip install [package-name]``` for any missing python packages. This should come included in python 3.4+ but can also be installed manually.
https://pip.pypa.io/en/stable/installing/

Run
```python LogSpiral.py```